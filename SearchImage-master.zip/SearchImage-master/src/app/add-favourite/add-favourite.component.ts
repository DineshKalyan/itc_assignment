import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { SearchService } from '../search-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { FavImage } from '../stores/image/image.model';
import { ImageStore } from '../stores/image/image.store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-favourite',
  templateUrl: './add-favourite.component.html',
  styleUrls: ['./add-favourite.component.css']
})
export class AddFavouriteComponent implements OnInit, OnDestroy {
  listName: any = "";
  list: string = "";
  data: any;
  link: String;
  favImages: any;
  pageUrl: any;
  imageName: any;
  val1: any;
  display: boolean;
  list1: any;
  listValues: any = [];
  list2: any;
  lists: FavImage[] = [];
  object: FavImage;
  showInput: boolean;
  favList: boolean;
  favLists: string[];
  imagesSubscription: Subscription;

  constructor(private service: SearchService, public snackBar: MatSnackBar, private dialogRef: MatDialogRef<AddFavouriteComponent>, @Inject(MAT_DIALOG_DATA) data,
    private imageStore: ImageStore) {
    this.data = data;
    //this.link = data.pageURL
    this.pageUrl = data.user.name
    this.imageName = data.alt_description;
    console.log(data);
  }

  ngOnInit(): void {
    this.imagesSubscription = this.imageStore.images$.subscribe(data => {
      this.lists = data.favouriteImages;
      if (this.lists.length != 0) {
        this.favList = true;
        this.favLists = [...new Set(this.lists.map(x => x.name))]
      }
      console.log(this.lists);
    });
  }

  ngOnDestroy() {
    this.imagesSubscription.unsubscribe();
  }

  addSelected() {
    // this.service.sendData(this.data);
  }

  onRadioBtnClick(list) {
    this.val1 = list;
  }

  addToFavourities(listName) {
    // if(listName === undefined){
    // alert("Input field cannot be empty")
    // }else{
    console.log(this.list);
    this.object = { "name": this.listName, "imageUrl": this.data.urls.small };
    // this.service.sendData(this.object);
    this.imageStore.addFavImage(this.object);
    // }
  }

  addToExisting(listName) {
    console.log(listName)
    this.object = { "name": listName, "imageUrl": this.data.urls.small }
    // this.service.sendData(this.object);
    this.imageStore.addFavImage(this.object);
  }

  addNewList() {
    this.showInput = true
  }
}
