import { Component, OnInit } from '@angular/core';

import { SearchService } from '../search-service.service';
import { FavImage } from '../stores/image/image.model';

@Component({
  selector: 'app-saved-images',
  templateUrl: './saved-images.component.html',
  styleUrls: ['./saved-images.component.css']
})
export class SavedImagesComponent implements OnInit {
  favImage: any;
  listNames: string[];

  constructor(private service: SearchService) { }

  ngOnInit(): void {
    this.favImage = {};
    this.listNames = [];
    const images = [...new Set(this.service.receiveData())];
    images.forEach((img: FavImage, idx) => {
      if (!this.favImage[img.name]) {
        this.listNames.push(img.name);
        this.favImage[img.name] = [];
      }
      this.favImage[img.name].push(img.imageUrl);
    });
  }

  // downloadFav(i) {
  //   const imgUrl = i.links.download;
  //   var a = document.createElement("a"); //Create <a>
  //   a.href = "data:image/jpeg;base64," + imgUrl; //Image Base64 Goes here
  //   a.download = "data:image/jpeg;base64," + imgUrl;; //File name Here
  //   a.click();
  // }

  downloadFav(imageUrl) {
    this.toDataURL(imageUrl, function (dataUrl) {
      console.log(dataUrl)
      var a = document.createElement("a"); //Create <a>
      a.href = dataUrl; //Image Base64 Goes here
      a.download = "Image.png"; //File name Here
      a.click();
    });
  }

  toDataURL(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
      var reader = new FileReader();
      reader.onloadend = function () {
        callback(reader.result);
      }
      reader.readAsDataURL(xhr.response);
    };
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.send();
  }
}
