import { Injectable } from '@angular/core';
import { throwError as observableThrowError, Observable } from 'rxjs';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import * as imageActions from './image.action';
import { SearchService } from '../../search-service.service';

@Injectable({
    providedIn: 'root'
})
export class ImageEffects {

    @Effect()
    load$: Observable<Action> = this.actions$
        .pipe(
            ofType(imageActions.ActionTypes.LOAD),
            map((action: imageActions.LoadAction) => action.payload),
            switchMap((query: string) => {
                return this.searchService.getSearchResult(query).pipe(
                    map(response => new imageActions.LoadSuccessAction(<any>response)),
                    catchError((err: any) => {
                        return observableThrowError(new imageActions.LoadFailureAction(err));
                    }));
            }));

    constructor(
        private searchService: SearchService,
        private actions$: Actions) { }
}
