import * as imageActions from './image.action';
import * as _ from 'lodash';

import { initialImageState, Image } from './image.model';

export function ImageReducer(state = initialImageState.images, action: imageActions.Actions): Image[] {

    switch (action.type) {
        case imageActions.ActionTypes.LOAD_SUCCESS: {
            const storeAction = <imageActions.LoadSuccessAction>action;
            state = _.cloneDeep(storeAction.payload.results);
            return state;
        }

        case imageActions.ActionTypes.LOAD_FAILURE:
        case imageActions.ActionTypes.RESET:
        default: {
            return initialImageState.images;
        }
    }
}
