import * as imageActions from './image.action';
import * as _ from 'lodash';

import { initialImageState, Image } from './image.model';

export function ImageReducer(state = initialImageState, action: imageActions.Actions) {

    switch (action.type) {
        case imageActions.ActionTypes.LOAD_SUCCESS: {
            const storeAction = <imageActions.LoadSuccessAction>action;
            const clonedState = _.cloneDeep(state);
            clonedState.searchImages = _.cloneDeep(storeAction.payload.results);
            return clonedState;
        }

        case imageActions.ActionTypes.ADD_FAV_IMAGE_SUCCESS: {
            const storeAction = <imageActions.AddFavImageSuccessAction>action;
            const clonedState = _.cloneDeep(state);
            clonedState.favouriteImages.push(_.cloneDeep(storeAction.payload));
            return clonedState;
        }

        case imageActions.ActionTypes.LOAD_FAILURE:
        case imageActions.ActionTypes.RESET:
        default: {
            const clonedState = _.cloneDeep(state);
            clonedState.searchImages = initialImageState.searchImages;
            return clonedState;
        }
    }
}
