import { Action } from '@ngrx/store';

const ACTION_PREFIX = '[image] ';

export const ActionTypes = {
    LOAD: ACTION_PREFIX + 'load images',
    LOAD_SUCCESS: ACTION_PREFIX + 'load images success',
    LOAD_FAILURE: ACTION_PREFIX + 'load images failure',

    RESET: ACTION_PREFIX + 'reset'
};

export class LoadAction implements Action {
    type = ActionTypes.LOAD;

    constructor(public payload: string) { }
}

export class LoadSuccessAction implements Action {
    type = ActionTypes.LOAD_SUCCESS;

    constructor(public payload: any) { }
}

export class LoadFailureAction implements Action {
    type = ActionTypes.LOAD_FAILURE;

    constructor(public payload: any) { }
}

export class ResetAction implements Action {
    type = ActionTypes.RESET;

    constructor() { }
}

export type Actions
    = LoadAction
    | LoadSuccessAction
    | LoadFailureAction
    | ResetAction;
