import { Action } from '@ngrx/store';

const ACTION_PREFIX = '[image] ';

export const ActionTypes = {
    LOAD: ACTION_PREFIX + 'load images',
    LOAD_SUCCESS: ACTION_PREFIX + 'load images success',
    LOAD_FAILURE: ACTION_PREFIX + 'load images failure',

    ADD_FAV_IMAGE: ACTION_PREFIX + 'add fav images',
    ADD_FAV_IMAGE_SUCCESS: ACTION_PREFIX + 'add fav images success',

    RESET: ACTION_PREFIX + 'reset'
};

export class LoadAction implements Action {
    type = ActionTypes.LOAD;

    constructor(public payload: string) { }
}

export class LoadSuccessAction implements Action {
    type = ActionTypes.LOAD_SUCCESS;

    constructor(public payload: any) { }
}

export class LoadFailureAction implements Action {
    type = ActionTypes.LOAD_FAILURE;

    constructor(public payload: any) { }
}

export class AddFavImageAction implements Action {
    type = ActionTypes.ADD_FAV_IMAGE;

    constructor(public payload: any) { }
}

export class AddFavImageSuccessAction implements Action {
    type = ActionTypes.ADD_FAV_IMAGE_SUCCESS;

    constructor(public payload: any) { }
}

export class ResetAction implements Action {
    type = ActionTypes.RESET;

    constructor() { }
}

export type Actions
    = LoadAction
    | LoadSuccessAction
    | LoadFailureAction
    | AddFavImageAction
    | AddFavImageSuccessAction
    | ResetAction;
