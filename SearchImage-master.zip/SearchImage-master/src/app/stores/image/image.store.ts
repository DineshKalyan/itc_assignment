import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';

import * as imageActions from './image.action';
import { Image, FavImage } from './image.model';

@Injectable({
    providedIn: 'root'
})
export class ImageStore {
    images$: Observable<{ searchImages: Image[], favouriteImages: FavImage[] }>;

    constructor(private store: Store<any>) {
        this.images$ = this.store.select(s => s.Image);
    }

    load(searchTerm) {
        this.store.dispatch({ type: imageActions.ActionTypes.LOAD, payload: searchTerm });
    }

    addFavImage(img) {
        this.store.dispatch({ type: imageActions.ActionTypes.ADD_FAV_IMAGE_SUCCESS, payload: img });
    }

    reset() {
        this.store.dispatch({ type: imageActions.ActionTypes.RESET });
    }
}
