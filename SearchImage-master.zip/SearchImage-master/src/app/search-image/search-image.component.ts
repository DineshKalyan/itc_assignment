import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { SearchService } from '../search-service.service';
import { ImageStore } from '../stores/image/image.store';
import { AddFavouriteComponent } from '../add-favourite/add-favourite.component';
import { Subscription } from 'rxjs';

import { Image } from '../stores/image/image.model';

@Component({
  selector: 'app-search-image',
  templateUrl: './search-image.component.html',
  styleUrls: ['./search-image.component.scss']
})
export class SearchImageComponent implements OnInit, OnDestroy {
  searchTerm: string;
  loading: boolean = false;
  images: Image[];
  imagesSubscription: Subscription;

  constructor(private service: SearchService, private dialog: MatDialog,
    private imageStore: ImageStore) {
  }

  ngOnInit(): void {
    this.imageStore.reset();
    this.imagesSubscription = this.imageStore.images$.subscribe(data => {
      setTimeout(() => {
        this.loading = false;
        this.images = data;
      }, this.searchTerm ? 1000 : 0);
    });
  }

  ngOnDestroy() {
    this.imagesSubscription.unsubscribe();
  }

  addSelected(i: number): void {
    const dialogRef = this.dialog.open(AddFavouriteComponent, {
      width: '500px',
      height: '200px',
      data: this.images[i]
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
    });
  }

  search() {
    // this.service.getSearchResult(this.searchTerm).subscribe(result => {
    //   this.images = result["results"]
    // });
    if (this.searchTerm) {
      this.loading = true;
      this.imageStore.load(this.searchTerm);
    } else {
      this.imageStore.reset();
    }
  }
}
